const fs = require ("fs");
const path = require("path");
const imageSchema = require("./imageSchema");
const commentSchema = require("./commentSchema");

const mongoose = require("mongoose");

// A Schema defines the "shape" of entries in a collection. This is similar to
// defining the columns of an SQL Database.
const PostSchema = new mongoose.Schema({
  userId: {type: mongoose.Schema.Types.ObjectId, ref: 'User'},
  content: {type: String, required: true},
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  image: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Image'
  }],
  comments: [commentSchema],
}, { timestamps: true });

const imagePath = path.join(__dirname, "..", "..", "pictures", "puppies.jpeg");
const imageData = fs.readFileSync(imagePath);
const Post = mongoose.model("Post", PostSchema);

const dateTimeString = new Date().toLocaleString("en-GB");

module.exports = Post;
